# Validation téléphone — à effectuer avant l’essai terrain

Appareil : __________  
Système : __________  
Navigateur et version : __________  
Date : __________

## Installation et persistance

- [ ] Ouvrir la version HTTPS et l’installer sur l’écran d’accueil si souhaité.
- [ ] Démarrer une séance, fermer puis rouvrir l’application : la même séance et son chrono réapparaissent.
- [ ] Faire START SET, recharger, puis vérifier que la même série reste active.
- [ ] Faire END SET, recharger, puis vérifier que la saisie attend toujours son résultat et que l’heure de fin n’a pas changé.

## TIME-10 — écran verrouillé

- [ ] Démarrer la corde ou le vélo et noter l’heure, la phase et le temps restant.
- [ ] Verrouiller l’écran cinq minutes.
- [ ] Déverrouiller et noter séparément :
  - état/temps reconstruits : ____________________ ;
  - sons ou alertes réellement reçus pendant le verrouillage : ____________________.
- [ ] Vérifier que l’application demande confirmation du réalisé et ne crédite pas automatiquement les minutes écoulées.

## Lisibilité et gestes rapides

- [ ] Boutons START/END, Enregistrer, +30 s et Corriger lisibles sans zoom.
- [ ] Saisie d’une série possible d’une main sans défilement anormal.
- [ ] Passage Mathieu ↔ Partenaire sans transfert de séance, série, repos ou mensuration.
- [ ] C Base 13, C Courte 11 et Jambes RETURN 12 affichent les bons exercices dans le bon ordre.

## Résultat

- Reprise des chronos : [ ] conforme  [ ] anomalie
- Alertes écran verrouillé : [ ] reçues  [ ] partielles  [ ] absentes
- Utilisation terrain autorisée : [ ] oui  [ ] après correction
- Notes :

____________________________________________________________________

