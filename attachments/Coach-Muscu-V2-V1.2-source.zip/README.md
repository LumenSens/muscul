# Coach Muscu V2 — V1.2

Application web locale issue de Coach Muscu et alignée sur la spécification finale V1.2.

## Programme installé

- lundi : Haut A ;
- mardi : nouveau Haut B ;
- jeudi 19 h : futsal 5 contre 5, 1 h ;
- vendredi : Haut C Base 13 par défaut ;
- samedi 13 h 30 : une seule séance jambes, RETURN 12 par défaut ;
- mercredi et dimanche normalement libres ; aucun Bas A.

Haut C propose Base 13, Avec complément 15 (shrugs **ou** oiseau, jamais les deux) et Courte 11. Le développé serré reste la référence ; l’extension au-dessus de la tête est une substitution TEST, jamais un ajout.

Les échauffements haut affichent une cible de 6–10 min, approches comprises, avec la référence terrain de 6–8 min pour Haut B. La corde de 4 min 30 et le vélo de 22 min restent des blocs séparés. Les deux vélos sont indiqués comme utilisables en parallèle avec des résultats personnels.

## Démarrage

Servir tout le dossier depuis la même origine HTTPS que l’ancienne application, puis ouvrir `index.html`. L’application ne nécessite ni serveur métier ni compte.

Pour un contrôle local, un serveur statique suffit, par exemple :

```bash
python3 -m http.server 8080
```

Puis ouvrir `http://localhost:8080`. L’installation PWA et le service worker demandent HTTPS en dehors de `localhost`.

## Reprise des données

1. Exporter d’abord une sauvegarde depuis l’ancienne application.
2. Si la V2 remplace l’ancienne sur la même origine, elle détecte les anciennes clés locales et construit un candidat V2 sans supprimer la source.
3. Sinon, aller dans **Sauvegarde → Importer**, puis sélectionner ou coller le JSON ancien.
4. Vérifier le rapport : la fixture contrôlée donne 199 résumés, 54 observations détaillées, 179 agrégats sans détail, 27 groupes de séance, 33 états et 8 anciens modèles.
5. Exporter immédiatement une **Sauvegarde complète V2** après validation.

Un import identique est un no-op. Un même identifiant avec deux contenus différents crée un conflit visible et conserve les deux versions dans l’export complet. Le paquet ne contient aucune sauvegarde, aucun journal et aucune performance réellement enregistrée.

## Données et usage

- Les profils Mathieu et Partenaire restent strictement séparés.
- START/END SESSION et START/END SET utilisent des horodatages persistants.
- Vide, inconnu et zéro explicite restent distincts.
- Les bandes enregistrent leur couleur/ID/inscription/configuration, jamais une force fictive en kg.
- Une modification Base/Courte/Complément pendant C conserve les séries déjà réalisées et adapte seulement le restant.
- Les données résident dans le stockage local du navigateur : effectuer des exports complets réguliers.

## Validation

Les résultats détaillés sont dans `IMPLEMENTATION_REPORT.md` et `tests/`. L’essai sur téléphone réel, notamment écran verrouillé, reste à effectuer avec `MANUAL_PHONE_TEST.md` avant usage terrain définitif.
